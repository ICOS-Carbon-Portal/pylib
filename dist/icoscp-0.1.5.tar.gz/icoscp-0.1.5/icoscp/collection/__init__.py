"""
    The Station Module is used to give easy access to 
    station metadata, corresponding data products and
    digital objects (data)
"""
