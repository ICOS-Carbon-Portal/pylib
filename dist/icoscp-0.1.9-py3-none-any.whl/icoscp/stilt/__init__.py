"""
    The Station Module is used to give easy access to 
    STILT results. Find STILT stations, and get access
	to timeseries and spatial footprints.
"""
